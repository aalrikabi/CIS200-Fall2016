#include <iostream>
#include<string>
//#include "lab8_1.h"
using namespace std;
int main()
{
}