#include "stdafx.h"
#include "CppUnitTest.h"
#include "../../Battle.h"
#include "../../Ship.h"
#include <string>
using namespace std;
using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace UnitTest2
{
	TEST_CLASS(UnitTest1)
	{
	public:

		TEST_METHOD(TestMethod1)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Ship("super",0,0,us,0,0,0);
		}

		TEST_METHOD(TestBattleship_alignment_us)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",0,0,us);
			Assert::AreEqual(0, fleet[0]->getX());
			int getallign= fleet[0]->getAlign();
			int valuealign=us;
			Assert::AreEqual(valuealign,getallign);
		}
		TEST_METHOD(TestBattleship_alignemt_them)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",0,0,them);
			Assert::AreEqual(0, fleet[0]->getX());
			int getallign= fleet[0]->getAlign();
			int valuealign=them;
			Assert::AreEqual(valuealign,getallign);

			//dont use ENUM in Assert
			//Error	1	error C2338: Test writer must define specialization of
			//	ToString<const Q& q> for your class class std::basic_string<wchar_t,struct std::char_traits<wchar_t>,
			//class std::allocator<wchar_t> > __cdecl Microsoft::VisualStudio::CppUnitTestFramework::ToString<enum Alignment>
			//	(const enum Alignment &).	c:\program files\microsoft visual studio 11.0\vc\unittest\include\cppunittestassert.h
			//	66	1	UnitTest2
			Assert::AreEqual(int (them),int( fleet[0]->getAlign()));
		}
		TEST_METHOD(TestBattleship_alignemt_cheotic)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",0,0,chaotic);
			Assert::AreEqual(0, fleet[0]->getX());
			int getallign= fleet[0]->getAlign();
			int valuealign=chaotic;
			Assert::AreEqual(valuealign,getallign);
		}
		TEST_METHOD(TestBattleship_setname)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",0,0,chaotic);
			string outputval= fleet[0]->getName();
			string expectedval="super";
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_setx)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",44,0,chaotic);
			int outputval= fleet[0]->getX();
			int expectedval=44;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_sety)
		{
			Ship** fleet;
			int numShip; //cout<<"How many ships do you want ?";
			//cin>> numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",44,865,chaotic);
			int outputval= fleet[0]->getY();
			int expectedval=865;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_move)
		{	// always moves along the vector (-1, -1)
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",44,865,chaotic);
			fleet[0]->move();
			int outputval= fleet[0]->getX();
			int expectedval=44-1;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[0]->getY();
			expectedval=865-1;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_move_increase_health)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",44,865,chaotic);
			fleet[0]->setCurrentHealth(55);
			fleet[0]->move();

			outputval=fleet[0]->getCurrentHealth();
			expectedval=56;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",10,15,us);
			fleet[1] = new Battle("Mrbeen",9,8,them);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}

		TEST_METHOD(TestBattleship_attack_outofrange)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",10,15,us);
			fleet[1] = new Battle("Mrbeen",90,8,them);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
		}

		TEST_METHOD(TestBattleship_attack_negativelocation)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-12,-11,us);
			fleet[1] = new Battle("Mrbeen",-15,-9,them);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_negative_us)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,us);
			fleet[1] = new Battle("Mrbeen",2,0,them);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_myownships)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,us);
			fleet[1] = new Battle("Mrbeen",2,0,us);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_chaoticship)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,us);
			fleet[1] = new Battle("Mrbeen",2,0,chaotic);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_chaoticship_attacking_chaotic)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,chaotic);
			fleet[1] = new Battle("Mrbeen",2,0,chaotic);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_us_attacking_chaotic)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,us);
			fleet[1] = new Battle("Mrbeen",2,0,chaotic);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_them_attacking_chaotic)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",2,0,chaotic);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=80;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_them_attacking_chaotic_outofrange)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",20,0,chaotic);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_them_attacking_chaotic_killtheship_healthNONnegative)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[1]->setCurrentHealth(9);
			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=0;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_them_attacking_chaotic_deadship)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[1]->setCurrentHealth(0);

			fleet[0]->attack(fleet[1]);
			outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=0;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_moving_dontincreaseHealthMorethanMax)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[0]->move();
			fleet[1]->move();
			/*outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
			*/
			outputval=fleet[1]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_withtorpedos)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[1]->setCurrentHealth(100);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[1]->setCurrentHealth(50);
			fleet[0]->attack(fleet[1]);

			/*outputval=fleet[0]->getCurrentHealth();
			expectedval=100;
			Assert::AreEqual(expectedval,outputval);
			*/
			outputval=fleet[1]->getCurrentHealth();
			expectedval=40;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_with_last_torpedo)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[1]->setCurrentHealth(100);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			//fleet[0]->attack(fleet[1]);
			fleet[1]->setCurrentHealth(50);
			fleet[0]->attack(fleet[1]);

			outputval=fleet[1]->getCurrentHealth();
			expectedval=30;
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_moving_deadship)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Ship** fleet;
			int numShip;
			numShip = 5;
			fleet= new Ship *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[0]->setCurrentHealth(0);
			fleet[0]->move();

			outputval=fleet[0]->getX();
			expectedval=(-5);
			Assert::AreEqual(expectedval,outputval);

			outputval=fleet[0]->getY();
			expectedval= (-3);
			Assert::AreEqual(expectedval,outputval);
		}
		TEST_METHOD(TestBattleship_attack_torpedo_check)
		{	// always moves along the vector (-1, -1)
			int outputval= 0;
			int expectedval=0;
			Battle** fleet;
			int numShip;
			numShip = 5;
			fleet= new Battle *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[1]->setCurrentHealth(100);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);

			//outputval=fleet[0]->get;
			//outputval=fleet[0]->get
			//outputval=fleet[0]->getY();
			outputval=fleet[0]->getTotalTorpedos();
			expectedval=2;
			Assert::AreEqual(expectedval,outputval);
		}TEST_METHOD(TestBattleship_status)
		{	// always moves along the vector (-1, -1)
			string outputval= " ";
			string expectedval= " ";
			Battle** fleet;
			int numShip;
			numShip = 5;
			fleet= new Battle *[numShip];
			fleet[0] = new Battle("super",-5,-3,them);
			fleet[1] = new Battle("Mrbeen",0,0,chaotic);
			fleet[0]->attack(fleet[1]);
			fleet[0]->attack(fleet[1]);

			string statusstring =" ";
			statusstring= "\n name: super\n type: Battle Ship\n Torpedoes: "+ to_string(8) +
				"\n Health: " + to_string(100)
				+ "\n Location: " + "(" + to_string(-5) + "," + to_string(-3) + ")\n";
			outputval=fleet[0]->status();
			expectedval= statusstring;
			Assert::AreEqual(expectedval,outputval);
		}
	};
}