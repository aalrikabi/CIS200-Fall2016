#include "stdafx.h"
#include "Cruiser.h"

Cruiser::Cruiser(string shipname, int xlocation, int ylocation, Alignment shipalign)
	:Ship(" ",0,0,us,0,0,0)
{
}

Cruiser::~Cruiser(void)
{
}