#include "stdafx.h"
#include "Repair.h"

Repair::Repair(string name)
	:Cruiser("",0,0,us)
{
}

Repair::~Repair(void)
{
}